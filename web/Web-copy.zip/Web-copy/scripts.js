// Obtener el elemento que desencadena la apertura del menú
